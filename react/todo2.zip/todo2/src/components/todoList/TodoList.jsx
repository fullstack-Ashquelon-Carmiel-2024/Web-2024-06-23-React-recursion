import './TodoList.css';

export default function TodoList() {
  return (
    <ul>
        <li>Run 10 km</li>
        <li>Learn React for 7 hours</li>
        <li>Wash Dishes</li>
        <li>Buy Eggs</li>
    </ul>
  )
}
