import './Header.css';

const Header = () => {
  return (
    <h1 className="header">TODO</h1>
  )
}


export default Header;